# Romanov — Rede Social Filosófica

Uma rede social minimalista de inspiração greco-romana onde pessoas compartilham frases como filósofas.

## Stack

- **Next.js 16** (App Router)
- **PostgreSQL** + **Drizzle ORM**
- **Tailwind CSS v4**
- **bcryptjs** + **jose** (JWT via cookies HTTP-only)

## Funcionalidades

- ✅ Cadastro e login (por nome de usuário ou e-mail)
- ✅ Publicar frases filosóficas com imagem opcional
- ✅ Sistema de votos (estrela) nas frases
- ✅ Ranking global (#) exibido ao lado do nome
- ✅ Seguir/deixar de seguir outros pensadores
- ✅ Contador de seguidores em tempo real
- ✅ Feed global e feed de quem você segue
- ✅ Perfil completo com estatísticas
- ✅ Página de Recordes (Top 10 usuários e Top 10 frases)
- ✅ Upload de imagens (local/public)

## Deploy no Vercel

### 1. Banco de dados

Use **Neon** (postgres serverless gratuito): https://neon.tech

Crie um banco e copie a connection string.

### 2. Variáveis de ambiente no Vercel

No painel do Vercel, adicione:

```
DATABASE_URL=postgresql://...sua-string-do-neon...
JWT_SECRET=qualquer-string-secreta-longa-e-aleatoria
```

### 3. Schema do banco

Após o primeiro deploy (ou localmente com o banco remoto):

```bash
npx drizzle-kit push
```

### 4. Upload de imagens no Vercel

> ⚠️ O Vercel não persiste arquivos entre deploys. Para produção, use:
> - [Vercel Blob](https://vercel.com/docs/storage/vercel-blob)
> - [Cloudinary](https://cloudinary.com) (gratuito)
> - [Uploadthing](https://uploadthing.com)

Para adaptar o upload, edite `src/app/api/upload/route.ts` e use a SDK desejada.

### 5. Deploy

```bash
git init
git add .
git commit -m "Initial commit - Romanov"
# Conecte ao Vercel via CLI ou interface web
vercel deploy
```

## Desenvolvimento local

```bash
# Instalar dependências
npm install

# Configurar banco local
cp .env.example .env
# Edite .env com sua DATABASE_URL local

# Aplicar schema
npx drizzle-kit push

# Iniciar servidor
npm run dev
```
