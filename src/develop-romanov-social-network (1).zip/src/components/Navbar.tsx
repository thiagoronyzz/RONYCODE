"use client";

import React, { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/context/AuthContext";
import { useToast } from "./Toast";
import Avatar from "./Avatar";
import AuthModal from "./AuthModal";
import { useRouter } from "next/navigation";

export default function Navbar() {
  const { user, logout } = useAuth();
  const { showToast } = useToast();
  const router = useRouter();
  const [authModal, setAuthModal] = useState(false);
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [menuOpen, setMenuOpen] = useState(false);

  function openLogin() {
    setAuthTab("login");
    setAuthModal(true);
  }

  function openRegister() {
    setAuthTab("register");
    setAuthModal(true);
  }

  async function handleLogout() {
    await logout();
    showToast("Até logo.", "info");
    router.push("/");
    setMenuOpen(false);
  }

  return (
    <>
      <header
        className="sticky top-0 z-40 border-b backdrop-blur-sm"
        style={{
          backgroundColor: "rgba(250,249,247,0.95)",
          borderColor: "#e5e0d7",
        }}
      >
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <span
              className="text-xl font-bold tracking-tight"
              style={{
                fontFamily: 'Georgia, "Times New Roman", serif',
                color: "#1e1a15",
                letterSpacing: "-0.02em",
              }}
            >
              Romanov
            </span>
            <span
              className="hidden sm:block text-xs font-normal mt-0.5"
              style={{ color: "#9a8b79", fontStyle: "italic" }}
            >
              · fórum filosófico
            </span>
          </Link>

          {/* Nav links */}
          <nav className="hidden sm:flex items-center gap-6">
            <Link
              href="/"
              className="text-sm font-medium transition-colors hover:text-stone-900"
              style={{ color: "#7d6e5e" }}
            >
              Início
            </Link>
            <Link
              href="/records"
              className="text-sm font-medium transition-colors hover:text-stone-900"
              style={{ color: "#7d6e5e" }}
            >
              Recordes
            </Link>
          </nav>

          {/* Auth */}
          <div className="flex items-center gap-3">
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  className="flex items-center gap-2 rounded-full p-0.5 transition-all"
                >
                  <Avatar
                    name={user.displayName}
                    avatarUrl={user.avatarUrl}
                    size="sm"
                  />
                </button>

                {menuOpen && (
                  <>
                    <div
                      className="fixed inset-0"
                      onClick={() => setMenuOpen(false)}
                    />
                    <div
                      className="absolute right-0 top-full mt-2 w-52 rounded-lg border shadow-lg z-50 overflow-hidden"
                      style={{
                        backgroundColor: "#faf9f7",
                        borderColor: "#d0c8bb",
                      }}
                    >
                      <div
                        className="px-4 py-3 border-b"
                        style={{ borderColor: "#e5e0d7" }}
                      >
                        <p
                          className="text-sm font-semibold"
                          style={{ color: "#1e1a15" }}
                        >
                          {user.displayName}
                        </p>
                        <p className="text-xs" style={{ color: "#9a8b79" }}>
                          @{user.username}
                        </p>
                      </div>
                      <Link
                        href={`/profile/${user.username}`}
                        onClick={() => setMenuOpen(false)}
                        className="block px-4 py-2.5 text-sm transition-colors hover:bg-stone-100"
                        style={{ color: "#3d352c" }}
                      >
                        Meu perfil
                      </Link>
                      <Link
                        href="/records"
                        onClick={() => setMenuOpen(false)}
                        className="block px-4 py-2.5 text-sm transition-colors hover:bg-stone-100 sm:hidden"
                        style={{ color: "#3d352c" }}
                      >
                        Recordes
                      </Link>
                      <button
                        onClick={handleLogout}
                        className="block w-full text-left px-4 py-2.5 text-sm transition-colors hover:bg-stone-100"
                        style={{ color: "#c0614e" }}
                      >
                        Sair
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <>
                <button
                  onClick={openLogin}
                  className="text-sm font-medium transition-colors hover:text-stone-900"
                  style={{ color: "#7d6e5e" }}
                >
                  Entrar
                </button>
                <button
                  onClick={openRegister}
                  className="px-3 py-1.5 rounded text-sm font-semibold transition-all"
                  style={{
                    backgroundColor: "#1e1a15",
                    color: "#f5f0e8",
                  }}
                >
                  Criar conta
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {authModal && (
        <AuthModal
          defaultTab={authTab}
          onClose={() => setAuthModal(false)}
        />
      )}
    </>
  );
}
